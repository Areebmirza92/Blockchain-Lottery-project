// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Simple decentralized lottery
/// @notice Players buy equal-value tickets; manager picks a random winner who receives the full pot.
contract Lottery {
    address public manager;
    address[] public players;
    uint256 public ticketPrice;
    address public lastWinner;
    uint256 public lastPrize;
    uint256 public roundId;

    event TicketPurchased(address indexed player, uint256 round);
    event WinnerPicked(address indexed winner, uint256 amount, uint256 round);

    constructor(uint256 _ticketPrice) {
        manager = msg.sender;
        ticketPrice = _ticketPrice;
        roundId = 1;
    }

    modifier onlyManager() {
        require(msg.sender == manager, "Only manager");
        _;
    }

    function enter() external payable {
        require(msg.value == ticketPrice, "Incorrect ticket price");
        players.push(msg.sender);
        emit TicketPurchased(msg.sender, roundId);
    }

    function getPlayers() external view returns (address[] memory) {
        return players;
    }

    function getPot() external view returns (uint256) {
        return address(this).balance;
    }

    function playerCount() external view returns (uint256) {
        return players.length;
    }

    /// @dev Pseudo-random — for production use Chainlink VRF.
    function _random() private view returns (uint256) {
        return uint256(
            keccak256(abi.encodePacked(block.prevrandao, block.timestamp, players.length, players))
        );
    }

    function pickWinner() external onlyManager {
        require(players.length > 0, "No players");
        uint256 index = _random() % players.length;
        address winner = players[index];
        uint256 prize = address(this).balance;

        lastWinner = winner;
        lastPrize = prize;

        emit WinnerPicked(winner, prize, roundId);

        roundId += 1;
        delete players;

        (bool sent, ) = winner.call{value: prize}("");
        require(sent, "Transfer failed");
    }
}
