const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Lottery", function () {
  it("accepts entries and picks a winner", async function () {
    const [manager, p1, p2] = await ethers.getSigners();
    const price = ethers.parseEther("0.5");
    const Lottery = await ethers.getContractFactory("Lottery");
    const lottery = await Lottery.deploy(price);
    await lottery.waitForDeployment();

    await lottery.connect(p1).enter({ value: price });
    await lottery.connect(p2).enter({ value: price });

    expect(await lottery.playerCount()).to.equal(2n);
    await expect(lottery.connect(manager).pickWinner()).to.emit(lottery, "WinnerPicked");
    expect(await lottery.playerCount()).to.equal(0n);
  });
});
