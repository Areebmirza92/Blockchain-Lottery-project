const hre = require("hardhat");

async function main() {
  const ticketPrice = hre.ethers.parseEther("0.5");
  const Lottery = await hre.ethers.getContractFactory("Lottery");
  const lottery = await Lottery.deploy(ticketPrice);
  await lottery.waitForDeployment();
  const address = await lottery.getAddress();
  console.log("Lottery deployed to:", address);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
