import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { BrowserProvider, Contract, formatEther, parseEther, type Eip1193Provider } from "ethers";
import { LOTTERY_ABI, LOTTERY_ADDRESS } from "@/lib/lottery";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast, Toaster } from "sonner";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "ChainLot — Decentralized Lottery on Ethereum" },
      { name: "description", content: "Buy a ticket, win the pot. A trustless on-chain lottery built with Solidity, Hardhat and ethers." },
    ],
  }),
});

declare global {
  interface Window {
    ethereum?: Eip1193Provider & { on?: (e: string, cb: (...args: unknown[]) => void) => void };
  }
}

function short(addr: string) {
  return addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : "";
}

function Index() {
  const [account, setAccount] = useState<string>("");
  const [manager, setManager] = useState<string>("");
  const [pot, setPot] = useState<string>("0");
  const [players, setPlayers] = useState<string[]>([]);
  const [ticketPrice, setTicketPrice] = useState<string>("0");
  const [lastWinner, setLastWinner] = useState<string>("");
  const [lastPrize, setLastPrize] = useState<string>("0");
  const [round, setRound] = useState<string>("1");
  const [busy, setBusy] = useState(false);

  const deployed = LOTTERY_ADDRESS && LOTTERY_ADDRESS !== "0x0000000000000000000000000000000000000000";

  const getContract = useCallback(async (signed = false) => {
    if (!window.ethereum) throw new Error("Install MetaMask");
    const provider = new BrowserProvider(window.ethereum);
    const runner = signed ? await provider.getSigner() : provider;
    return new Contract(LOTTERY_ADDRESS, LOTTERY_ABI, runner);
  }, []);

  const refresh = useCallback(async () => {
    if (!deployed || !window.ethereum) return;
    try {
      const c = await getContract();
      const [m, p, pl, tp, lw, lp, r] = await Promise.all([
        c.manager(), c.getPot(), c.getPlayers(), c.ticketPrice(),
        c.lastWinner(), c.lastPrize(), c.roundId(),
      ]);
      setManager(m); setPot(formatEther(p)); setPlayers(pl);
      setTicketPrice(formatEther(tp));
      setLastWinner(lw); setLastPrize(formatEther(lp)); setRound(r.toString());
    } catch (e) {
      console.error(e);
    }
  }, [deployed, getContract]);

  const connect = useCallback(async () => {
    if (!window.ethereum) { toast.error("MetaMask not found"); return; }
    const provider = new BrowserProvider(window.ethereum);
    const accs = await provider.send("eth_requestAccounts", []);
    setAccount(accs[0]);
    refresh();
  }, [refresh]);

  useEffect(() => { refresh(); }, [refresh]);

  const enter = async () => {
    try {
      setBusy(true);
      const c = await getContract(true);
      const tx = await c.enter({ value: parseEther(ticketPrice) });
      toast.message("Buying ticket…");
      await tx.wait();
      // Optimistic update so pot & player count bump immediately
      setPlayers((prev) => (account ? [...prev, account] : prev));
      setPot((prev) => (Number(prev) + Number(ticketPrice)).toString());
      toast.success("You're in! Good luck.");
      refresh();
    } catch (e) {
      const err = e as { shortMessage?: string; message?: string };
      toast.error(err.shortMessage || err.message || "Transaction failed");
    } finally { setBusy(false); }
  };

  const pickWinner = async () => {
    try {
      setBusy(true);
      const c = await getContract(true);
      const tx = await c.pickWinner();
      toast.message("Drawing winner…");
      await tx.wait();
      toast.success("Winner picked!");
      refresh();
    } catch (e) {
      const err = e as { shortMessage?: string; message?: string };
      toast.error(err.shortMessage || err.message || "Transaction failed");
    } finally { setBusy(false); }
  };

  const isManager = account && manager && account.toLowerCase() === manager.toLowerCase();

  return (
    <div className="min-h-screen" style={{ background: "var(--gradient-hero)" }}>
      <Toaster theme="dark" position="top-center" />
      <header className="flex items-center justify-between px-6 md:px-12 py-6">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-xl" style={{ background: "var(--gradient-gold)", boxShadow: "var(--shadow-glow)" }} />
          <span className="text-xl font-bold tracking-tight">ChainLot</span>
        </div>
        <Button onClick={connect} variant={account ? "secondary" : "default"} className="rounded-full">
          {account ? short(account) : "Connect Wallet"}
        </Button>
      </header>

      <main className="px-6 md:px-12 pb-24 max-w-6xl mx-auto">
        <section className="text-center pt-12 pb-16">
          <span className="inline-block px-3 py-1 rounded-full text-xs uppercase tracking-widest border border-border text-muted-foreground">
            Round #{round} · Trustless · On-chain
          </span>
          <h1 className="mt-6 text-5xl md:text-7xl font-black tracking-tight leading-[1.05]">
            Buy a ticket.<br />
            <span style={{ background: "var(--gradient-gold)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Win the pot.
            </span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
            A fully on-chain lottery written in Solidity. Smart contract holds the pot. No middlemen.
          </p>
        </section>

        <section className="grid md:grid-cols-3 gap-5">
          <Card className="p-6 col-span-2 bg-card border-border" style={{ boxShadow: "var(--shadow-card)" }}>
            <div className="text-sm text-muted-foreground uppercase tracking-wider">Current Pot</div>
            <div className="mt-2 text-6xl font-black tracking-tight" style={{ background: "var(--gradient-gold)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              {Number(pot).toFixed(4)} ETH
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button size="lg" onClick={enter} disabled={!account || !deployed || busy} className="rounded-full font-semibold">
                Buy Ticket · {ticketPrice} ETH
              </Button>
              {isManager && (
                <Button size="lg" variant="secondary" onClick={pickWinner} disabled={busy || players.length === 0} className="rounded-full">
                  Draw Winner
                </Button>
              )}
            </div>
            {!deployed && (
              <p className="mt-4 text-sm text-destructive">
                Contract not deployed. Run <code className="font-mono">npx hardhat run scripts/deploy.cjs</code> and set <code className="font-mono">VITE_LOTTERY_ADDRESS</code>.
              </p>
            )}
          </Card>

          <Card className="p-6 bg-card border-border" style={{ boxShadow: "var(--shadow-card)" }}>
            <div className="text-sm text-muted-foreground uppercase tracking-wider">Players</div>
            <div className="mt-2 text-6xl font-black">{players.length}</div>
            <div className="mt-4 text-sm text-muted-foreground">in this round</div>
            {lastWinner && lastWinner !== "0x0000000000000000000000000000000000000000" && (
              <div className="mt-6 pt-6 border-t border-border">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Last Winner</div>
                <div className="font-mono mt-1">{short(lastWinner)}</div>
                <div className="text-sm text-primary mt-1">won {Number(lastPrize).toFixed(4)} ETH</div>
              </div>
            )}
          </Card>
        </section>

        <section className="mt-10">
          <Card className="p-6 bg-card border-border">
            <h2 className="text-lg font-semibold mb-4">Players in this round</h2>
            {players.length === 0 ? (
              <p className="text-muted-foreground text-sm">No tickets yet. Be the first.</p>
            ) : (
              <ul className="grid sm:grid-cols-2 md:grid-cols-3 gap-2">
                {players.map((p, i) => (
                  <li key={`${p}-${i}`} className="font-mono text-sm px-3 py-2 rounded-lg bg-muted">
                    #{i + 1} {short(p)}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </section>

        <section className="mt-16 grid md:grid-cols-3 gap-5">
          {[
            { t: "1. Connect", d: "Connect MetaMask to the network where the contract is deployed." },
            { t: "2. Enter", d: `Send ${ticketPrice} ETH to buy a ticket. The pot grows with each entry.` },
            { t: "3. Win", d: "When the manager draws, a random player receives the entire pot." },
          ].map((s) => (
            <div key={s.t} className="p-5 rounded-2xl border border-border">
              <div className="text-primary font-semibold">{s.t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
