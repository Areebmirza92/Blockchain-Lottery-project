// Lottery contract config + ABI for the frontend.
// After deploying with Hardhat, paste the deployed address here.
export const LOTTERY_ADDRESS =
  (import.meta.env.VITE_LOTTERY_ADDRESS as string) || "0x5FbDB2315678afecb367f032d93F642f64180aa3";

export const LOTTERY_ABI = [
  "function manager() view returns (address)",
  "function ticketPrice() view returns (uint256)",
  "function lastWinner() view returns (address)",
  "function lastPrize() view returns (uint256)",
  "function roundId() view returns (uint256)",
  "function getPlayers() view returns (address[])",
  "function getPot() view returns (uint256)",
  "function playerCount() view returns (uint256)",
  "function enter() payable",
  "function pickWinner()",
  "event TicketPurchased(address indexed player, uint256 round)",
  "event WinnerPicked(address indexed winner, uint256 amount, uint256 round)",
];
