# ChainLot — Decentralized Lottery

Solidity contract + ethers v6 + TanStack Start frontend.

## Smart contract

```bash
# compile
npx hardhat compile

# test
npx hardhat test

# run local node (separate terminal)
npx hardhat node

# deploy to local node
npx hardhat run scripts/deploy.cjs --network localhost

# deploy to Sepolia (set SEPOLIA_RPC_URL and PRIVATE_KEY env vars)
npx hardhat run scripts/deploy.cjs --network sepolia
```

After deployment, copy the address into a `.env` file at the project root:

```
VITE_LOTTERY_ADDRESS=0xYourDeployedAddress
```

Then connect MetaMask to the same network in the UI.

## Notes

The contract uses `block.prevrandao` for randomness — fine for demos but **not secure for real money**. For production, integrate Chainlink VRF.
